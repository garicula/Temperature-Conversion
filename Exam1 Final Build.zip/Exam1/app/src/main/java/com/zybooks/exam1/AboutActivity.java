// This is the "about" activity that we needed for the first button

package com.zybooks.exam1;

// The androidx import needed for this part
import androidx.appcompat.app.AppCompatActivity;

// The basic android bundle features were needed as well
import android.os.Bundle;

// This class creates the layout for this activity
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // "super" lets our code run in addition to the existing code
        super.onCreate(savedInstanceState);

        // This sets the layout for the about activity to the corresponding .xml file
        setContentView(R.layout.about_activity);
    }
}