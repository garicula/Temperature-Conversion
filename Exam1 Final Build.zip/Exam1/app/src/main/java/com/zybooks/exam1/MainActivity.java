// Garrick Morley
// ISYS 221-001
// Exam 1; Website Link / About Button / Unit Conversion
// Date: 10/07/2021

package com.zybooks.exam1;

// The androidx import that was needed
import androidx.appcompat.app.AppCompatActivity;

// All of the normal android imports needed for the program
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// Main class to run everything
public class MainActivity extends AppCompatActivity {

    // Create the main layout from the .xml file
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create and connect the button to get to the about section when clicked
        Button about = (Button) findViewById(R.id.button1);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                aboutActivity();
            }
        });

        // Create and link the button to get to the website when clicked
        Button website = (Button) findViewById(R.id.button2);
        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToUrl("https://www.rapidtables.com/convert/temperature/how-celsius-to-fahrenheit.html");
            }
        });

        // Create the button object to submit the entered Celsius text
        Button conversion = (Button) findViewById(R.id.button3);

        // Function to convert the entered Celsius text when clicked
        conversion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convert();
            }
        });

    }

    // Supporting function to send you to the "about" activity
    public void aboutActivity()
    {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    // Supporting function to send you to the conversion website
    public void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    // Supporting function / algorithm that works with the conversion button above
    public void convert()
    {
        // Create and set an EditText object to the value in the .xml file
        EditText et = (EditText) findViewById(R.id.editText);

        // Declare some necessary variables for the algorithm below
        double alpha;
        double beta;
        String charlie;
        double delta;

        // The algorithm that converts the given Celsius temperature into Fahrenheit
        alpha = Double.parseDouble(String.valueOf(et.getText()));
        beta = (alpha * 1.8);
        delta = (beta + 32);
        charlie = String.valueOf(delta);

        // The toast import is then used to display the result
        Toast.makeText(MainActivity.this,charlie + "°C",Toast.LENGTH_SHORT).show();
    }



}